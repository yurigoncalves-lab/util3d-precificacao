// ========================================================
// 1. CONFIGURAÇÕES GERAIS (FÁCIL DE EDITAR!)
// ========================================================
// Altere esses valores sempre que o preço das coisas mudar.
// Você não precisa mexer no resto do código.

const CONFIG = {
    custoKgPLA: 120.00,       // Preço que você paga no kg do filamento (R$)
    tarifaEnergia: 0.90,      // Valor do kWh em Curitiba/Copel (R$)
    wattsImpressora: 130,     // Consumo médio da Bambu Lab A1 (Watts)
    custoImpressora: 3000.00, // Valor de compra da impressora (R$)
    vidaUtilHoras: 3000,      // Vida útil estimada da impressora (Horas)
    maoObraFixaJob: 2.00      // Regra padrão de mão de obra (R$)
};

// ========================================================
// 2. LÓGICA DE CÁLCULO (REGRA DE NEGÓCIO)
// ========================================================
function calcular() {
    // Pegando os valores que o usuário digitou na tela
    let tempo = parseFloat(document.getElementById('tempo').value) || 0;
    let peso = parseFloat(document.getElementById('peso').value) || 0;
    let qtdJob = parseInt(document.getElementById('qtdJob').value) || 1;
    let taxaFalha = parseFloat(document.getElementById('taxaFalha').value);
    let margem = parseFloat(document.getElementById('margem').value);
    let maoObraExtra = parseFloat(document.getElementById('maoObraExtra').value) || 0;

    // Fazendo a matemática com base na sua documentação
    let custoMaterial = (peso / 1000) * CONFIG.custoKgPLA; 
    let custoEnergia = (CONFIG.wattsImpressora / 1000) * tempo * CONFIG.tarifaEnergia;
    let custoDepreciacao = (CONFIG.custoImpressora / CONFIG.vidaUtilHoras) * tempo;
    
    // Diluição da mão de obra
    let maoObraDiluida = CONFIG.maoObraFixaJob / qtdJob; 
    let maoObraTotal = maoObraDiluida + maoObraExtra;

    // Custos totais
    let custoBase = custoMaterial + custoEnergia + custoDepreciacao + maoObraTotal;
    let custoComFalha = custoBase * (1 + taxaFalha); 
    let precoSugerido = custoComFalha / (1 - margem); 

    // ========================================================
    // 3. ATUALIZAÇÃO DA TELA (FRONT-END)
    // ========================================================
    
    // Mostra o painel de resultados
    document.getElementById('resultado-panel').classList.remove('hidden');

    // Formata para a moeda brasileira (R$) e exibe
    const formatarMoeda = (valor) => valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

    document.getElementById('resMaterial').innerText = formatarMoeda(custoMaterial);
    document.getElementById('resEnergia').innerText = formatarMoeda(custoEnergia);
    document.getElementById('resDepreciacao').innerText = formatarMoeda(custoDepreciacao);
    document.getElementById('resMaoObra').innerText = formatarMoeda(maoObraTotal);
    document.getElementById('resCustoTecnico').innerText = formatarMoeda(custoComFalha);
    document.getElementById('resPreco').innerText = formatarMoeda(precoSugerido);
}
